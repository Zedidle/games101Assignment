
#ifndef RASTERIZER_RECTANGLE_H
#define RASTERIZER_RECTANGLE_H
#include <eigen3/Eigen/Eigen>


using namespace Eigen;

class Rectangle
{
    // public:


};



#endif // RASTERIZER_RECTANGLE_H
